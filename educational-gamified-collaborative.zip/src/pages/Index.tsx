import React from 'react';
import AppLayout from '@/components/AppLayout';

const Index: React.FC = () => {
  return <AppLayout />;
};

export default Index;
